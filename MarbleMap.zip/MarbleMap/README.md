MarbleMap v1.3.8
=======================

map editor for rpg games.export json config file.

if you want to get a English version.you can mail me:sxmad@163.com
